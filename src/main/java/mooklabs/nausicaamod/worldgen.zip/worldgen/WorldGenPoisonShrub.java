package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import papercut.nausicaamod.Main;

public class WorldGenPoisonShrub extends WorldGenerator
{
    private int logMeta;//fields are metadata for log and leaves
    private int leafMeta;//not useing anymore
    private Block leaf = Main.poisonLeaves;
    private Block log = Main.poisonLog;
    
    public WorldGenPoisonShrub()
    {
        this.logMeta = 0;
        this.leafMeta = 0;
    }
    public WorldGenPoisonShrub(Block logBlock, Block leafBlock)
    {
        this.logMeta = 0;
        this.leafMeta = 0;
        log = logBlock;
        leaf = leafBlock;
    }
    public WorldGenPoisonShrub(Block logBlock, Block leafBlock, int logmeta, int leafmeta)
    {
    	this.logMeta = logmeta;
        this.leafMeta = leafmeta;
        log = logBlock;
        leaf = leafBlock;
    }

    public boolean generate(World par1World, Random par2Random, int par3, int par4, int par5)
    {
        int l;

        Block block = null;
        do 
        {
            block = par1World.getBlock(par3,  par4, par5);
            if (block != null && !block.isAir(par1World, par3, par4, par5) && !block.isLeaves(par1World, par3, par4, par5))
            {
                break;
            }
            par4--;
        } while (par4 > 0);

        Block soil = par1World.getBlock(par3, par4, par5);

        
       if (soil == Main.poisonDirt || soil == Main.poisonGrass)
      //  if (i1 == Block.dirt.blockID || i1 == Block.grass.blockID)
        {
            ++par4;
            this.setBlockAndNotifyAdequately(par1World, par3, par4, par5, log, this.logMeta);

            for (int j1 = par4; j1 <= par4 + 2; ++j1)
            {
                int k1 = j1 - par4;
                int l1 = 2 - k1;

                for (int i2 = par3 - l1; i2 <= par3 + l1; ++i2)
                {
                    int j2 = i2 - par3;

                    for (int k2 = par5 - l1; k2 <= par5 + l1; ++k2)
                    {
                        int l2 = k2 - par5;

                        block = par1World.getBlock(i2, j1, k2);

                        if ((Math.abs(j2) != l1 || Math.abs(l2) != l1 || par2Random.nextInt(2) != 0) && 
                            (block == null || block.canBeReplacedByLeaves(par1World, i2, j1, k2)))
                        {
                            this.setBlockAndNotifyAdequately(par1World, i2, j1, k2, leaf, this.leafMeta);
                        }
                    }
                }
            }
        }

        return true;
    }
}
