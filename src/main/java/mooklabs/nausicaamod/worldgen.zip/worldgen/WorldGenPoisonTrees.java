package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSapling;
import net.minecraft.init.Blocks;
import net.minecraft.util.Direction;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.util.ForgeDirection;
import papercut.nausicaamod.Main;

public class WorldGenPoisonTrees extends WorldGenerator
{
    /** The minimum height of a generated tree. */
    private final int minTreeHeight;

    /** True if this tree should grow Vines. */
    private final boolean vinesGrow;

    /** The metadata value of the wood to use in tree generation. */
    private final int metaWood;

    /** The metadata value of the leaves to use in tree generation. */
    private final int metaLeaves;

    /** Sets the block id for the vines(or puffballs) used in huge trees */
    Block vineBlock = Blocks.vine;//Main.puffball.blockID;
    
    public WorldGenPoisonTrees(boolean par1)
    {
        this(par1, 4, 0, 0, false);
    }

    public WorldGenPoisonTrees(boolean par1, int par2, int par3, int par4, boolean par5)
    {
        super(par1);
        this.minTreeHeight = par2;
        this.metaWood = par3;
        this.metaLeaves = par4;
        this.vinesGrow = par5;
    }

    public boolean generate(World par1World, Random par2Random, int par3, int par4, int par5)
    {
    	
        int l = par2Random.nextInt(3) + this.minTreeHeight;
        boolean flag = true;

        if (par4 >= 1 && par4 + l + 1 <= 256)
        {
            int i1;
            byte b0;
            int j1;

            for (i1 = par4; i1 <= par4 + 1 + l; ++i1)
            {
                b0 = 1;

                if (i1 == par4)
                {
                    b0 = 0;
                }

                if (i1 >= par4 + 1 + l - 2)
                {
                    b0 = 2;
                }

                for (int l1 = par3 - b0; l1 <= par3 + b0 && flag; ++l1)
                {
                    for (j1 = par5 - b0; j1 <= par5 + b0 && flag; ++j1)
                    {
                        if (i1 >= 0 && i1 < 256)
                        {
                            Block block = par1World.getBlock(l1, i1, j1);


                            if (!par1World.isAirBlock(l1, i1, j1) &&
                                !block.isLeaves(par1World, l1, i1, j1) &&
                                 block != Main.poisonGrass &&
                                 block != Main.poisonDirt &&
                                !block.isWood(par1World, l1, i1, j1))//isWood is in the blocklog class and just returns true
                            {
                                flag = false;
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag)
            {
                return false;
            }
            else
            {
                Block soil = par1World.getBlock(par3, par4 - 1, par5);
                boolean isSoil = (soil != null && soil.canSustainPlant(par1World, par3, par4 - 1, par5, ForgeDirection.UP, (BlockSapling)Blocks.sapling));

                if (isSoil && par4 < 256 - l - 1)
                {
                    soil.onPlantGrow(par1World, par3, par4 - 1, par5, par3, par4, par5);
                    b0 = 3;
                    byte b1 = 0;
                    int i2=0;
                    int j2=0;
                    int k2=0;

                    for (j1 = par4 - b0 + l; j1 <= par4 + l; ++j1)
                    {
                       

                        for (j2 = par3 - i2; j2 <= par3 + i2; ++j2)
                        {
                            k2 = j2 - par3;

                            for (int l2 = par5 - i2; l2 <= par5 + i2; ++l2)
                            {
                                int i3 = l2 - par5;

                                if (Math.abs(k2) != i2 || Math.abs(i3) != i2 || par2Random.nextInt(2) != 0)
                                {
                                    Block block = par1World.getBlock(j2, j1, l2);

                                    if (block == null || block.canBeReplacedByLeaves(par1World, j2, j1, l2))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, j2, j1, l2, Main.poisonLeaves, this.metaLeaves);
                                    }
                                }
                            }
                        }
                    }

                    for (j1 = 0; j1 < l; ++j1)
                    {
                        Block block = par1World.getBlock(par3, par4 + j1, par5);


                        if (block == null || block.isAir(par1World, par3, par4 + j1, par5) || block.isLeaves(par1World, par3, par4 + j1, par5))
                        {
                            this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5, Main.poisonLog, this.metaWood);

                            if (this.vinesGrow && j1 > 0)
                            {
                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 - 1, par4 + j1, par5))
                                    this.setBlockAndNotifyAdequately(par1World, par3 - 1, par4 + j1, par5, vineBlock, 8);

                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 + 1, par4 + j1, par5))
                                    this.setBlockAndNotifyAdequately(par1World, par3 + 1, par4 + j1, par5, vineBlock, 2);

                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3, par4 + j1, par5 - 1))
                                    this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5 - 1, vineBlock, 1);

                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3, par4 + j1, par5 + 1))
                                    this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5 + 1, vineBlock, 4);
                            }
                        }
                    }

                    if (this.vinesGrow)
                    {
                        for (j1 = par4 - 3 + l; j1 <= par4 + l; ++j1)
                        {
                            

                            for (j2 = par3 - i2; j2 <= par3 + i2; ++j2)
                            {
                                for (k2 = par5 - i2; k2 <= par5 + i2; ++k2)
                                {
                                    Block block = par1World.getBlock(j2, j1, k2);
                                    if (block != null && block.isLeaves(par1World, j2, j1, k2))
                                    {
                                        if (par2Random.nextInt(4) == 0 && par1World.isAirBlock(j2 - 1, j1, k2))
                                        {
                                            this.growVines(par1World, j2 - 1, j1, k2, 8);
                                        }

                                        if (par2Random.nextInt(4) == 0 && par1World.isAirBlock(j2 + 1, j1, k2))
                                        {
                                            this.growVines(par1World, j2 + 1, j1, k2, 2);
                                        }

                                        if (par2Random.nextInt(4) == 0 && par1World.isAirBlock(j2, j1, k2 - 1))
                                        {
                                            this.growVines(par1World, j2, j1, k2 - 1, 1);
                                        }

                                        if (par2Random.nextInt(4) == 0 && par1World.isAirBlock(j2, j1, k2 + 1))
                                        {
                                            this.growVines(par1World, j2, j1, k2 + 1, 4);
                                        }
                                    }
                                }
                            }
                        }/*
                        if(false)//take out coco beans
                        if (par2Random.nextInt(5) == 0 && l > 5 )
                        {
                            for (j1 = 0; j1 < 2; ++j1)
                            {
                                
                                    if (par2Random.nextInt(4 - j1) == 0)
                                    {
                                        i2 = par2Random.nextInt(3);
                                        this.setBlockAndNotifyAdequately(par1World, par3, par4 + l - 5 + j1, par5 , Blocks.cocoa, i2 << 2);
                                    
                                }
                            }
                        }*/
                    }

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        else
        {
            return false;
        }
    }

    /**
     * Grows vines downward from the given block for a given length. Args: World, x, starty, z, vine-length
     */
    private void growVines(World par1World, int par2, int par3, int par4, int par5)
    {
        this.setBlockAndNotifyAdequately(par1World, par2, par3, par4, vineBlock, par5);
        int i1 = 4;

        while (true)
        {
            --par3;

            if (!par1World.isAirBlock(par2, par3, par4) || i1 <= 0)
            {
                return;
            }

            this.setBlockAndNotifyAdequately(par1World, par2, par3, par4, vineBlock, par5);
            --i1;
        }
    }
}
