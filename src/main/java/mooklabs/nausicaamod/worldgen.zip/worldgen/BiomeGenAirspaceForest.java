package papercut.nausicaamod.worldgen;

import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityGhast;
import papercut.nausicaamod.Main;
import papercut.nausicaamod.mobs.JungleJelly;
import papercut.nausicaamod.mobs.Ohmu;

public class BiomeGenAirspaceForest extends NausicaaBiomeGenBase {

	public BiomeGenAirspaceForest(int par1) {
		super(par1);
		this.topBlock = Main.poisonGrass;
        this.fillerBlock = Main.poisonDirt;
        this.spawnableMonsterList.clear();
		this.spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 4, 4, 4));// TODO add correct spawns
		this.spawnableMonsterList.add(new SpawnListEntry(EntityCaveSpider.class, 50, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(JungleJelly.class, 200, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(Ohmu.class, 1, 0, 1));
	
	}

	

}
