package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import papercut.nausicaamod.Main;
import papercut.nausicaamod.mobs.JungleJelly;
import papercut.nausicaamod.mobs.Ohmu;

public class BiomeGenPoisonDesert extends NausicaaBiomeGenBase
{
    private byte topBlockMeta;
    private byte fillerBlockMeta;

    public BiomeGenPoisonDesert(int par1)
    {
        super(par1);
        this.theBiomeDecorator.treesPerChunk = 1;
        this.theBiomeDecorator.grassPerChunk = 1;
        this.theBiomeDecorator.flowersPerChunk = 0;// 4;
        this.topBlock = Main.poisonSand;
        this.topBlockMeta = 0;//TODO add meta for diff color sands?
        this.fillerBlock = Main.poisonSand;
        this.fillerBlockMeta = 1;
        this.spawnableMonsterList.clear();
		this.spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 4, 4, 1));// TODO add correct spawns
		this.spawnableMonsterList.add(new SpawnListEntry(EntityCaveSpider.class, 50, 10, 10));//class, chance, min, max
		this.spawnableMonsterList.add(new SpawnListEntry(JungleJelly.class, 200, 1, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(Ohmu.class, 10, 0, 1));
        //setTemperatureRainfall(0.9F, 1.0F);
        this.setColor(747097);
    }

    /**
     * Gets a WorldGen appropriate for this biome.
     */
    public WorldGenerator getRandomWorldGenForTrees(Random par1Random)
    {
	//if(par1Random.nextInt(200) == 0)
	    return new WorldGenPoisonShrub(Main.poisonLog, Main.puffball);
	//return null;
    }

    

    public void decorate(World par1World, Random par2Random, int par3, int par4)
    {
        super.decorate(par1World, par2Random, par3, par4);
        
    }
}
