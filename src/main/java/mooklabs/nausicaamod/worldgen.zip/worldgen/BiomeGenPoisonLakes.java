package papercut.nausicaamod.worldgen;

import papercut.nausicaamod.mobs.Ohmu;

public class BiomeGenPoisonLakes extends NausicaaBiomeGenBase {

	public BiomeGenPoisonLakes(int par1) {
		super(par1);
		this.spawnableCreatureList.clear();
		this.spawnableMonsterList.clear();
		
		this.spawnableMonsterList.add(new SpawnListEntry(Ohmu.class, 100, 0, 1));
		//TODO spawn ohmu others?
		}

}
