package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.gen.feature.WorldGenerator;
import papercut.nausicaamod.Main;
import papercut.nausicaamod.mobs.JungleJelly;
import papercut.nausicaamod.mobs.Ohmu;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class BiomeGenPoisonSwamp extends NausicaaBiomeGenBase {

	public BiomeGenPoisonSwamp(int par1) {
		super(par1);
		this.theBiomeDecorator.treesPerChunk = 2;
		this.theBiomeDecorator.flowersPerChunk = -999;
		this.theBiomeDecorator.deadBushPerChunk = 1;
		this.theBiomeDecorator.mushroomsPerChunk = 8;
		this.theBiomeDecorator.reedsPerChunk = 10;
		this.theBiomeDecorator.clayPerChunk = 1;
		this.theBiomeDecorator.waterlilyPerChunk = 4;
		this.waterColorMultiplier = 14745518;
		this.topBlock = Main.poisonGrass;
		this.fillerBlock = Main.poisonDirt;
		this.spawnableMonsterList.clear();
		this.spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 4,
				4, 4));// TODO add correct spawns
		this.spawnableMonsterList.add(new SpawnListEntry(
				EntityCaveSpider.class, 50, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(JungleJelly.class,
				200, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(Ohmu.class, 1, 0, 1));
	}

	/**
	 * Gets a WorldGen appropriate for this biome.
	 */
	public WorldGenerator getRandomWorldGenForTrees(Random par1Random) {
		return this.worldGeneratorSwamp;
	}

	@SideOnly(Side.CLIENT)
	/**
	 * Provides the basic grass color based on the biome temperature and rainfall
	 */
	public int getBiomeGrassColor() {
		double d0 = (double) this.temperature;
		double d1 = (double) this.getFloatRainfall();
		return ((ColorizerGrass.getGrassColor(d0, d1) & 16711422) + 5115470) / 2;
	}

	@SideOnly(Side.CLIENT)
	/**
	 * Provides the basic foliage color based on the biome temperature and rainfall
	 */
	public int getBiomeFoliageColor() {
		double d0 = (double) this.temperature;
		double d1 = (double) this.getFloatRainfall();
		return ((ColorizerFoliage.getFoliageColor(d0, d1) & 16711422) + 5115470) / 2;
	}
}
