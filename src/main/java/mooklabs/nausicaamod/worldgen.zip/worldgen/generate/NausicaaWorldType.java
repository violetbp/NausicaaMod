package papercut.nausicaamod.worldgen.generate;

import papercut.nausicaamod.Main;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;

public class NausicaaWorldType extends WorldType {

	/** Nausicaa world type. */
	public static WorldType NAUSICAA = (new NausicaaWorldType("nausicaa"));
	
	public NausicaaWorldType(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	
	public static void addRemoveNeededBiomes(){
		NAUSICAA.removeBiome(BiomeGenBase.desert);
        NAUSICAA.removeBiome(BiomeGenBase.forest);
        NAUSICAA.removeBiome(BiomeGenBase.jungle);
        NAUSICAA.removeBiome(BiomeGenBase.plains);
        NAUSICAA.removeBiome(BiomeGenBase.ocean);
        NAUSICAA.removeBiome(BiomeGenBase.taiga);
        NAUSICAA.removeBiome(BiomeGenBase.swampland);
        NAUSICAA.removeBiome(BiomeGenBase.frozenOcean);
        NAUSICAA.removeBiome(BiomeGenBase.frozenRiver);
        NAUSICAA.removeBiome(BiomeGenBase.iceMountains);
        NAUSICAA.removeBiome(BiomeGenBase.icePlains);
        NAUSICAA.removeBiome(BiomeGenBase.mushroomIsland);
        NAUSICAA.removeBiome(BiomeGenBase.mushroomIslandShore);
        NAUSICAA.removeBiome(BiomeGenBase.beach);
        NAUSICAA.removeBiome(BiomeGenBase.desertHills);
        NAUSICAA.removeBiome(BiomeGenBase.forestHills);
        NAUSICAA.removeBiome(BiomeGenBase.taigaHills);
        NAUSICAA.removeBiome(BiomeGenBase.extremeHillsEdge); 
        NAUSICAA.removeBiome(BiomeGenBase.extremeHills);


        //NAUSICAA.removeBiome(BiomeGenBase.river);//river is nice, but will have to change later!//TODO create own river

        NAUSICAA.addNewBiome(Main.poisonDesert);
		NAUSICAA.addNewBiome(Main.poisonForest);
		NAUSICAA.addNewBiome(Main.airspaceForest);
		NAUSICAA.addNewBiome(Main.poisonForestHills);
		//NAUSICAA.addNewBiome(Main.poisonForestLakes);
		NAUSICAA.addNewBiome(Main.poisonForestVillage);
		NAUSICAA.addNewBiome(Main.poisonSwamp);
	}
	
	public boolean hasVoidParticles(boolean flag)
    {
        return this != NAUSICAA && !flag;
    }



}
