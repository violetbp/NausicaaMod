package papercut.nausicaamod.worldgen.generate;

import papercut.nausicaamod.Main;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.ChunkProviderFlat;

public class WorldProviderToxic extends WorldProvider {

    public WorldProviderToxic() {
	// TODO Auto-generated constructor stub
    }

    @Override
    public String getDimensionName() {
	return "Nausicaa's World";
    }

    @Override
	public void registerWorldChunkManager() {
	this.worldChunkMgr = new NausicaaWorldChunkManager(worldObj.getSeed(),NausicaaWorldType.NAUSICAA);
	this.dimensionId = Main.dimensionId;
    }

    @Override
	public IChunkProvider createChunkGenerator() {
    	//return new ChunkProviderFlat(worldObj, dimensionId, hasNoSky, field_82913_c);
	return new ChunkProviderToxic(worldObj, worldObj.getSeed(), true);
    }

    @Override
	public String getWelcomeMessage() {
	return "Good Luck!";
    }

    

    @Override
	public boolean canRespawnHere() {
	return true;
    }
    
}
