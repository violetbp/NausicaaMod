package papercut.nausicaamod.worldgen.generate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.minecraft.world.ChunkPosition;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeCache;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.gen.layer.GenLayer;
import net.minecraft.world.gen.layer.IntCache;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.terraingen.WorldTypeEvent;
import papercut.nausicaamod.Main;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class NausicaaWorldChunkManager extends WorldChunkManager
{
    public static ArrayList<BiomeGenBase> allowedNausicaaBiomes = new ArrayList<BiomeGenBase>(Arrays.asList(Main.poisonDesert, Main.poisonForest));
    private GenLayer genBiomes;

    /** A GenLayer containing the indices into BiomeGenBase.biomeList[] */
    private GenLayer biomeIndexLayer;

    /** The BiomeCache object for this world. */
    private BiomeCache biomeCache;

 
    private List<BiomeGenBase> nausicaaBiomesToSpawnIn;
    
    protected NausicaaWorldChunkManager()
    {
        this.biomeCache = new BiomeCache(this);
      //  this.nausicaaBiomesToSpawnIn.addAll(allowedNausicaaBiomes);
    }

    public NausicaaWorldChunkManager(long par1, WorldType par3WorldType)
    {
        this();
        GenLayer[] agenlayer = GenLayer.initializeAllBiomeGenerators(par1, par3WorldType);
        agenlayer = getModdedBiomeGenerators(par3WorldType, par1, agenlayer);
        this.genBiomes = agenlayer[0];
        this.biomeIndexLayer = agenlayer[1];
    }

    public NausicaaWorldChunkManager(World par1World)
    {
        this(par1World.getSeed(), par1World.getWorldInfo().getTerrainType());
    }

    /**
     * Gets the list of valid biomes for the player to spawn in.
     */
    @Override
	public List getBiomesToSpawnIn()
    {
    	System.out.println("**********************************Biomes"+NausicaaWorldChunkManager.allowedNausicaaBiomes);
        return NausicaaWorldChunkManager.allowedNausicaaBiomes;
    }

    /**
     * Returns the BiomeGenBase related to the x, z position on the world.
     */
    @Override
	public BiomeGenBase getBiomeGenAt(int par1, int par2)
    {
        return this.biomeCache.getBiomeGenAt(par1, par2);
    }


    @Override
	@SideOnly(Side.CLIENT)

    /**
     * Return an adjusted version of a given temperature based on the y height
     */
    public float getTemperatureAtHeight(float par1, int par2)
    {
        return par1;
    }

    
    /**
     * Returns biomes to use for the blocks and loads the other data like temperature and humidity onto the
     * WorldChunkManager Args: oldBiomeList, x, z, width, depth
     */
    @Override
	public BiomeGenBase[] loadBlockGeneratorData(BiomeGenBase[] par1ArrayOfBiomeGenBase, int par2, int par3, int par4, int par5)
    {
        return this.getBiomeGenAt(par1ArrayOfBiomeGenBase, par2, par3, par4, par5, true);
    }

   
    /**
     * Calls the WorldChunkManager's biomeCache.cleanupCache()
     */
    @Override
	public void cleanupCache()
    {
        this.biomeCache.cleanupCache();
    }

    @Override
	public GenLayer[] getModdedBiomeGenerators(WorldType worldType, long seed, GenLayer[] original)
    {
        WorldTypeEvent.InitBiomeGens event = new WorldTypeEvent.InitBiomeGens(worldType, seed, original);
        MinecraftForge.TERRAIN_GEN_BUS.post(event);
        return event.newBiomeGens;
    }
}
