package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSapling;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.util.ForgeDirection;
import papercut.nausicaamod.Main;

public class WorldGenPoisonHugeTrees extends WorldGenerator
{
    /** The base height of the tree */
    private final int baseHeight;

    /** Sets the metadata for the wood blocks used */
    private final int woodMetadata;

    /** Sets the metadata for the leaves used in huge trees */
    private final int leavesMetadata;
    
    /** Sets the block for the vines(or puffballs) used in huge trees */
    Block vineBlock = Blocks.vine; //Main.puffball;
/**
 * 
 * @param par1 update blocks or soemthing, don't mess with it!
 * @param par2 base height XD
 */
    public WorldGenPoisonHugeTrees(boolean par1, int par2)//, int par3, int par4)
    {
        super(par1);
        this.baseHeight = par2;
        this.woodMetadata = 0;
        this.leavesMetadata = 0;
        
    }

    public boolean generate(World par1World, Random par2Random, int par3, int par4, int par5)
    {
        int l = par2Random.nextInt(3) + this.baseHeight;
        boolean flag = true;

        if (par4 >= 1 && par4 + l + 1 <= 256)
        {
            int i1;
            int j1;
            int k1;
            int l1;

            for (i1 = par4; i1 <= par4 + 1 + l; ++i1)
            {
                byte b0 = 2;

                if (i1 == par4)
                {
                    b0 = 1;
                }

                if (i1 >= par4 + 1 + l - 2)
                {
                    b0 = 2;
                }

                for (j1 = par3 - b0; j1 <= par3 + b0 && flag; ++j1)
                {
                    for (k1 = par5 - b0; k1 <= par5 + b0 && flag; ++k1)
                    {
                        if (i1 >= 0 && i1 < 256)
                        {
                            Block block = par1World.getBlock(j1, i1, k1);

                            if (block != null &&
                               !block.isAir(par1World, j1, i1, k1) &&
                               !block.isLeaves(par1World, j1, i1, k1) &&
                               !block.isWood(par1World, j1, i1, k1) &&
                                block != Blocks.grass &&
                                block != Blocks.dirt &&
                                block != Blocks.sapling)
                            {
                                flag = false;
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                }
            }

            if (!flag)
            {
                return false;
            }
            else
            {
               Block soil = par1World.getBlock(par3, par4 - 1, par5);
               boolean isValidSoil = soil != null && soil.canSustainPlant(par1World, par3, par4 - 1, par5, ForgeDirection.UP, (BlockSapling)Blocks.sapling);

                if (isValidSoil && par4 < 256 - l - 1)
                {
                    onPlantGrow(par1World, par3,     par4 - 1, par5,     par3, par4, par5);
                    onPlantGrow(par1World, par3 + 1, par4 - 1, par5,     par3, par4, par5);
                    onPlantGrow(par1World, par3,     par4 - 1, par5 + 1, par3, par4, par5);
                    onPlantGrow(par1World, par3 + 1, par4 - 1, par5 + 1, par3, par4, par5);
                    this.growLeaves(par1World, par3, par5, par4 + l, 2, par2Random);

                    for (int i2 = par4 + l - 2 - par2Random.nextInt(4); i2 > par4 + l / 2; i2 -= 2 + par2Random.nextInt(4))
                    {
                        float f = par2Random.nextFloat() * (float)Math.PI * 2.0F;
                        k1 = par3 + (int)(0.5F + MathHelper.cos(f) * 4.0F);
                        l1 = par5 + (int)(0.5F + MathHelper.sin(f) * 4.0F);
                        this.growLeaves(par1World, k1, l1, i2, 0, par2Random);

                        for (int j2 = 0; j2 < 5; ++j2)
                        {
                            k1 = par3 + (int)(1.5F + MathHelper.cos(f) * (float)j2);
                            l1 = par5 + (int)(1.5F + MathHelper.sin(f) * (float)j2);
                            this.setBlockAndNotifyAdequately(par1World, k1, i2 - 3 + j2 / 2, l1, Main.poisonLog, this.woodMetadata);
                        }
                    }

                    for (j1 = 0; j1 < l; ++j1)
                    {
                        Block block = par1World.getBlock(par3, par4 + j1, par5);

                        if (isReplaceable(par1World, par3, par4 + j1, par5))
                        {
                            this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5, Main.poisonLog, this.woodMetadata);

                            if (j1 > 0)
                            {
                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 - 1, par4 + j1, par5))
                                {
                                    this.setBlockAndNotifyAdequately(par1World, par3 - 1, par4 + j1, par5, vineBlock, 8);
                                }

                                if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3, par4 + j1, par5 - 1))
                                {
                                    this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5 - 1, vineBlock, 1);
                                }
                            }
                        }

                        if (j1 < l - 1)
                        {
                        	block = par1World.getBlock(par3 + 1, par4 + j1, par5);

                            if (isReplaceable(par1World, par3 + 1, par4 + j1, par5))
                            {
                                this.setBlockAndNotifyAdequately(par1World, par3 + 1, par4 + j1, par5, Main.poisonLog, this.woodMetadata);

                                if (j1 > 0)
                                {
                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 + 2, par4 + j1, par5))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3 + 2, par4 + j1, par5, vineBlock, 2);
                                    }

                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 + 1, par4 + j1, par5 - 1))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3 + 1, par4 + j1, par5 - 1, vineBlock, 1);
                                    }
                                }
                            }

                            block = par1World.getBlock(par3 + 1, par4 + j1, par5 + 1);

                            if (isReplaceable(par1World, par3 + 1, par4 + j1, par5 + 1))
                            {
                                this.setBlockAndNotifyAdequately(par1World, par3 + 1, par4 + j1, par5 + 1, Main.poisonLog, this.woodMetadata);

                                if (j1 > 0)
                                {
                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 + 2, par4 + j1, par5 + 1))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3 + 2, par4 + j1, par5 + 1, vineBlock, 2);
                                    }

                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 + 1, par4 + j1, par5 + 2))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3 + 1, par4 + j1, par5 + 2, vineBlock, 4);
                                    }
                                }
                            }

                            block = par1World.getBlock(par3, par4 + j1, par5 + 1);

                            if (isReplaceable(par1World, par3, par4 + j1, par5 + 1))
                            {
                                this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5 + 1, Main.poisonLog, this.woodMetadata);

                                if (j1 > 0)
                                {
                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3 - 1, par4 + j1, par5 + 1))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3 - 1, par4 + j1, par5 + 1, vineBlock, 8);
                                    }

                                    if (par2Random.nextInt(3) > 0 && par1World.isAirBlock(par3, par4 + j1, par5 + 2))
                                    {
                                        this.setBlockAndNotifyAdequately(par1World, par3, par4 + j1, par5 + 2, vineBlock, 4);
                                    }
                                }
                            }
                        }
                    }

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        else
        {
            return false;
        }
    }


/**
 * 
 * @param world
 * @param par2
 * @param par3
 * @param par4
 * @param par5
 * @param random
 */
    private void growLeaves(World world, int par2, int par3, int par4, int par5, Random random)
    {
        byte b0 = 2;

        for (int i1 = par4 - b0; i1 <= par4; ++i1)
        {
            int j1 = i1 - par4;
            int k1 = par5 + 1 - j1;

            for (int l1 = par2 - k1; l1 <= par2 + k1 + 1; ++l1)
            {
                int i2 = l1 - par2;

                for (int j2 = par3 - k1; j2 <= par3 + k1 + 1; ++j2)
                {
                    int k2 = j2 - par3;

                    if ((i2 >= 0 || k2 >= 0 || i2 * i2 + k2 * k2 <= k1 * k1) && (i2 <= 0 && k2 <= 0 || i2 * i2 + k2 * k2 <= (k1 + 1) * (k1 + 1)) && (random.nextInt(4) != 0 || i2 * i2 + k2 * k2 <= (k1 - 1) * (k1 - 1)))
                    {
                        Block block = world.getBlock(l1, i1, j2);

                        if (block == null || block.canBeReplacedByLeaves(world, l1, i1, j2))
                        {
                            this.setBlockAndNotifyAdequately(world, l1, i1, j2, Main.poisonLeaves, this.leavesMetadata);
                        }
                    }
                }
            }
        }
    }

    private void onPlantGrow(World world, int x, int y, int z, int sourceX, int sourceY, int sourceZ)
    {
        Block block = world.getBlock(x, y, z);
        if (block != null)
        {
            block.onPlantGrow(world, x, y, z, sourceX, sourceY, sourceZ);
        }
    }

    private boolean isReplaceable(World world, int x, int y, int z)
    {
        Block block = world.getBlock(x, y, z);
        return (block == null || block.isAir(world, x, y, z) || block.isLeaves(world, x, y, z));
    }
}
