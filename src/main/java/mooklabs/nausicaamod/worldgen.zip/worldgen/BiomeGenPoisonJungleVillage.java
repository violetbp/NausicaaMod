package papercut.nausicaamod.worldgen;

import java.util.Random;

import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import papercut.nausicaamod.Main;
import papercut.nausicaamod.mobs.JungleJelly;
import papercut.nausicaamod.mobs.Ohmu;

public class BiomeGenPoisonJungleVillage extends NausicaaBiomeGenBase {

	public BiomeGenPoisonJungleVillage(int par1) {
		super(par1);
        this.theBiomeDecorator.treesPerChunk = 500;// 50;
        this.theBiomeDecorator.grassPerChunk = 0;//25;
        this.theBiomeDecorator.flowersPerChunk = 0;// 4;
        this.theBiomeDecorator.generateLakes = true;//TODO remove?
        this.topBlock = Main.poisonGrass;
        this.fillerBlock = Main.poisonDirt;
        this.spawnableMonsterList.clear();
		this.spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 4, 4, 4));// TODO add correct spawns
		this.spawnableMonsterList.add(new SpawnListEntry(EntityCaveSpider.class, 50, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(JungleJelly.class, 200, 10, 10));
		this.spawnableMonsterList.add(new SpawnListEntry(Ohmu.class, 1, 0, 1));
        //setTemperatureRainfall(0.9F, 1.0F);
        this.setColor(747097);
        
	}
	/**
	 * Gets a WorldGen appropriate for this biome.
	 */
	@Override
	public WorldGenerator getRandomWorldGenForTrees(Random par1Random) {
		if (par1Random.nextInt(100) == 0) return new WorldGenPoisonShrub(Main.puffball, Main.puffball);
		if (par1Random.nextInt(9) == 0) return par1Random.nextInt(2) != 0 ? new WorldGenPoisonShrub(Main.puffball, null) : new WorldGenPoisonTrees(false, 
				4 + par1Random.nextInt(7), 3, 3, true);
		return new WorldGenPoisonHugeTrees(false, 10 + par1Random.nextInt(20));// a boolean, basehight, wood,leaves
		// return (WorldGenerator)(par1Random.nextInt(10) == 0 ? this.worldGeneratorBigTree : (par1Random.nextInt(2) == 0 ? new WorldGenShrub(3, 0) : (par1Random.nextInt(3) ==
		// 0 ? new WorldGenHugeTrees(false, 10 + par1Random.nextInt(20), Main.poisonLog, 3) : new WorldGenTrees(false, 4 + par1Random.nextInt(7), 3, 3, true))));
	}

	
	
	public void decorate(World par1World, Random par2Random, int par3, int par4) {
		super.decorate(par1World, par2Random, par3, par4);
		WorldGenPoisonVines worldgenvines = new WorldGenPoisonVines();
		for (int k = 0; k < 50; ++k) {
			int l = par3 + par2Random.nextInt(16) + 8;
			byte b0 = 64;
			int i1 = par4 + par2Random.nextInt(16) + 8;
			worldgenvines.generate(par1World, par2Random, l, b0, i1);
		}
		
		
	}
}
